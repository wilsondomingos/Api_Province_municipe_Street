@extends('layout.app', ["current" => "produtos" ])

@section('body')
    <h4>Página de produtos</h4>
@endsection